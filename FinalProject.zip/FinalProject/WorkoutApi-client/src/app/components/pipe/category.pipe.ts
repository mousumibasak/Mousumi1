import { Pipe, PipeTransform } from '@angular/core';

import { Category} from '../model/Category';

@Pipe({ name: 'categoryPipe' })
export class CategoryPipe implements PipeTransform {
   
   transform(items: any[], searchText: string): any {        
		if(!items) return [];
		if(!searchText) return items;	
		searchText = searchText.toLowerCase();	
        // filter items array, items which match and return true will be
        // kept, false will be filtered out		
		return items.filter( it => {
			console.log(it.categoryName);
			return it.categoryName.toLowerCase().includes(searchText);
		});   
   
        //return items.filter(item => item.categoryName.indexOf(searchText) !== -1);
    }
}