export interface Config {
  heroesUrl: string;
  textfile: string;
}