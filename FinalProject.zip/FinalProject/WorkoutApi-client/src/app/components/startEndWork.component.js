"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var Workout_1 = require("./model/Workout");
var WorkoutActive_1 = require("./model/WorkoutActive");
var workout_service_1 = require("./service/workout.service");
var StartEndWorkComponent = (function () {
    function StartEndWorkComponent(workoutService, router, route) {
        this.workoutService = workoutService;
        this.router = router;
        this.route = route;
        this.workout = new Workout_1.Workout();
        this.workoutActive = new WorkoutActive_1.WorkoutActive();
        this.activeworkout = new Workout_1.Workout();
        this.myDatePickerOptions = {
            dateFormat: 'dd.mm.yyyy'
        };
        this.currentDateTime = new Date();
        this.settings = {
            bigBanner: true,
            timePicker: true,
            format: 'hh:mm a',
            defaultOpen: false
        };
        this.workoutDate = { date: { year: this.currentDateTime.getFullYear(), month: this.currentDateTime.getMonth(), day: this.currentDateTime.getDay() + 1 } };
        this.route.params.subscribe(function (params) { return console.log(params); });
    }
    StartEndWorkComponent.prototype.ngOnInit = function () {
        this.page = this.route.snapshot.paramMap.get('page');
        this.workoutId = this.route.snapshot.paramMap.get('id');
        this.getWorkout(this.workoutId);
        console.log(this.page + " Workout Page.......");
    };
    /** GET getWorkout by id. Will 404 if id not found */
    StartEndWorkComponent.prototype.getWorkout = function (id) {
        var _this = this;
        this.workoutService.getWorkout(id)
            .subscribe(function (workout) { return _this.workout = workout; });
    };
    StartEndWorkComponent.prototype.cancelWorkoutActive = function () {
        this.router.navigate(['/ViewAllWorkout']);
    };
    StartEndWorkComponent.prototype.startEndWorkoutActive = function () {
        var _this = this;
        if (this.workoutDate != null) {
            var selectedDateTime = new Date(this.workoutDate.date.day + "/" +
                this.workoutDate.date.month + "/" + this.workoutDate.date.year);
            if (this.page == "Start") {
                this.workoutActive.startDateTm = selectedDateTime;
            }
            else {
                this.workoutActive.endDateTm = selectedDateTime;
            }
            console.log("this.workoutActive.startEndDateTm" + selectedDateTime);
            if (this.workoutActive != null) {
                this.activeworkout._id = this.workoutId;
                this.workoutActive.workout = this.activeworkout;
                this.workoutService.saveWorkoutActive(this.workoutActive)
                    .subscribe(function (workoutActive) {
                    console.log("workoutActive Saved");
                    _this.router.navigate(['/ViewAllWorkout']);
                });
            }
        }
    };
    return StartEndWorkComponent;
}());
StartEndWorkComponent = __decorate([
    core_1.Component({
        selector: 'app-root',
        templateUrl: './startEndWorkout.component.html',
        providers: [workout_service_1.WorkoutService],
        styleUrls: ['./public/css/app.css']
    }),
    __metadata("design:paramtypes", [workout_service_1.WorkoutService, router_1.Router, router_1.ActivatedRoute])
], StartEndWorkComponent);
exports.StartEndWorkComponent = StartEndWorkComponent;
//# sourceMappingURL=startEndWork.component.js.map