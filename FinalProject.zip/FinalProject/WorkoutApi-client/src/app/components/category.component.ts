import { Component } from '@angular/core';
import { Directive, OnInit, OnDestroy, Input } from '@angular/core';
import { CategoryService } from './service/category.service';
import { Config} from './model/Config';
import { Category} from './model/Category';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html', 
  providers: [ CategoryService ],
  styleUrls: ['./public/css/app.css']
})

export class CategoryComponent  implements OnInit  {
  error: any;
  headers: string[];
  config: Config;  
  newCategoryName:string;
  category:Category;
  srchWorkoutTxt:string[];
  categories:Category[];
  
  constructor(private categoryService: CategoryService) {}  
    
  ngOnInit() {		
	this.getAllCategories();
  } 
  
  //call service to list all available categories
  getAllCategories(): void {
	  this.categoryService.getAllCategories()
      .subscribe(categories => this.categories = categories);
  }
  //call service to update Category
  updateCategory(category:Category): void {
	console.log(category.categoryName);
	this.categoryService.updateCategory(category)
     .subscribe(() => console.log("Category Updated"));
 }
 //call service to save new Category
  addCategory(): void {
	  if (!this.newCategoryName) { 
			this.error="Category Name is Mandatory";
			return; 
	   }	  
	  this.error=null;
      this.category=new Category();	  
	  this.category.categoryName=this.newCategoryName;
	  console.log("this.category   "+this.category);
	  this.categoryService.saveCategory(this.category)
      .subscribe(category => {
		  this.newCategoryName="";
		  this.categories.push(category);
		  console.log("Category saved");        
      });
  } 
  
  deleteCategory(category:Category): void {
	console.log("Category ID Name To delete "+category._id+" "+category.categoryName);
	this.categories = this.categories.filter(h => h !== category);
    this.categoryService.deleteCategory(category).subscribe();
  } 
 
}