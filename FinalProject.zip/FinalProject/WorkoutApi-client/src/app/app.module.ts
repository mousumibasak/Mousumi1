import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { ChartsModule } from 'ng2-charts';

import { MyDatePickerModule } from 'mydatepicker';

import { AppComponent }  from './app.component';

import { ViewAllWorkoutComponent }  from './components/viewAllWorkout.component';
import { StartEndWorkComponent }  from './components/startEndWork.component';

import { WorkoutComponent }  from './components/workoutComponent.component';
import { CategoryComponent }  from './components/category.component';
import { TrackWorkoutComponent }  from './components/trackWorkout.component';

import { PageNotFoundComponent }  from './components/pageNotFound.component';
import { CategoryPipe} from './components/pipe/category.pipe';
import { WorkoutPipe} from './components/pipe/workout.pipe';

import { AngularDateTimePickerModule } from 'angular2-datetimepicker';

const appRoutes: Routes = [
  { path: 'ViewAllWorkout', component: ViewAllWorkoutComponent },
  { path: 'StartWorkout/:page/:id', component: StartEndWorkComponent,data: { page: 'StartWorkout' }},
  { path: 'EndWorkout/:page/:id', component: StartEndWorkComponent,data: { page: 'EndWorkout' } },
  { path: 'EditWorkout/:id',component: WorkoutComponent,data: { page: 'EditWorkout' } },
  { path: 'AddWorkout', component: WorkoutComponent,data: { page: 'AddWorkout' } },
  
  { path: 'Category', component: CategoryComponent },
  { path: 'Track', component: TrackWorkoutComponent },
  { path: '', redirectTo: '/ViewAllWorkout', pathMatch: 'full' },
  { path: '**', component: PageNotFoundComponent }
];



@NgModule({
  imports:[ BrowserModule,MyDatePickerModule,ChartsModule,
    HttpClientModule, AngularDateTimePickerModule,
	RouterModule.forRoot(appRoutes,{ enableTracing: true } // <-- debugging purposes only
    )
  ],
  declarations: [ AppComponent,CategoryPipe,WorkoutPipe, ViewAllWorkoutComponent,StartEndWorkComponent,WorkoutComponent,CategoryComponent,TrackWorkoutComponent,PageNotFoundComponent],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
